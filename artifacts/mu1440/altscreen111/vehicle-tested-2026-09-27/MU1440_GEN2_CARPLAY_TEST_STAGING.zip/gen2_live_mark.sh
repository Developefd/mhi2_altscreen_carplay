#!/bin/ksh
set -u

ACTIVE=/tmp/mibr-live-monitor.active
PIDFILE=/tmp/mibr-live-monitor.pid

SECONDS=0

now_human() {
    if [ -r "${timefile:-}" ]; then
        T=$(cat "$timefile" 2>/dev/null)
        [ -n "$T" ] && { echo "t+${T}s"; return 0; }
    fi
    echo "t+?s"
}

load_active() {
    if [ ! -r "$ACTIVE" ] || [ ! -r "$PIDFILE" ]; then
        echo "LIVE_MARK=FAIL no_active_monitor"
        return 20
    fi

    pid=
    journal=
    raw_journal=
    timefile=
    . "$ACTIVE"

    if [ -z "${pid:-}" ] || [ -z "${journal:-}" ] || [ -z "${raw_journal:-}" ] || [ -z "${timefile:-}" ]; then
        echo "LIVE_MARK=FAIL invalid_active_state"
        return 21
    fi

    if ! kill -0 "$pid" 2>/dev/null; then
        echo "LIVE_MARK=FAIL monitor_not_running pid=$pid"
        return 22
    fi
    return 0
}

write_note() {
    NOTE_TEXT=$1
    [ -n "$NOTE_TEXT" ] || return 0
    TS=$(now_human)
    echo "$TS [NOTE] $NOTE_TEXT" >> "$journal" || {
        echo "LIVE_MARK=FAIL compact_write"
        return 23
    }
    echo "$TS [NOTE] $NOTE_TEXT" >> "$raw_journal" || {
        echo "LIVE_MARK=FAIL raw_write"
        return 24
    }
    echo "MARKED: $NOTE_TEXT"
    return 0
}

load_active || exit $?

if [ "${1:-}" = "--loop" ]; then
    echo "LIVE_MARK_LOOP=RUNNING"
    echo "Type a comment + Enter. /paths shows files. /q exits."
    while :; do
        echo "comment>"
        IFS= read -r NOTE || break
        case "$NOTE" in
            "")
                ;;
            /q|/quit)
                break
                ;;
            /paths)
                load_active || exit $?
                echo "compact=$journal"
                echo "raw=$raw_journal"
                ;;
            *)
                load_active || exit $?
                write_note "$NOTE" || exit $?
                ;;
        esac
    done
    echo "LIVE_MARK_LOOP=STOPPED"
    exit 0
fi

if [ "$#" -gt 0 ]; then
    NOTE="$*"
else
    echo "comment>"
    IFS= read -r NOTE
fi

[ -n "$NOTE" ] || {
    echo "LIVE_MARK=SKIP empty_comment"
    exit 0
}

write_note "$NOTE" || exit $?
echo "compact=$journal"
echo "raw=$raw_journal"
