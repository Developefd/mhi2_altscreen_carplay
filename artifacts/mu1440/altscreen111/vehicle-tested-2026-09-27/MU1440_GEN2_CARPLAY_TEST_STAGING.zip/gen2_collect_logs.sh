#!/bin/ksh
set -u

BASE=/net/mmx/fs/sda0/esd/carplay-test
OUT=$BASE/gen2-last-report.txt
FULL_ALT=$BASE/gen2-last-altscreen111.log
STATUS_SNAPSHOT=$BASE/gen2-last-status.txt
REMUX_SNAPSHOT=$BASE/gen2-last-remux-status.txt
CAPTURE_SNAPSHOT=$BASE/gen2-last-capture-status.txt
DIRECT_ROOT=/mnt/app/root/altscreen-u2/logs/direct-ts

if [ -r /tmp/altscreen111.log ]; then
  cp /tmp/altscreen111.log "$FULL_ALT" 2>/dev/null || true
fi
if [ -r /tmp/mibr-alt111-gen2.status ]; then
  cp /tmp/mibr-alt111-gen2.status "$STATUS_SNAPSHOT" 2>/dev/null || true
fi
[ -r /tmp/mibr-direct-remux.status ] && cp /tmp/mibr-direct-remux.status "$REMUX_SNAPSHOT" 2>/dev/null || true
[ -r /tmp/mibr-alt111-capture.status ] && cp /tmp/mibr-alt111-capture.status "$CAPTURE_SNAPSHOT" 2>/dev/null || true

{
  echo "=== GEN2 REPORT ==="
  date 2>/dev/null || true
  echo
  "$BASE/gen2_status.sh" 2>/dev/null || true

  echo
  echo "=== dio_manager environment ==="
  DIO=$(pidin ar 2>/dev/null | awk '/[d]io_manager/ {print $1; exit}')
  [ -n "$DIO" ] && pidin -p "$DIO" environment 2>/dev/null |
    grep -E 'LD_PRELOAD|ALTSCREEN111_|IPL_CONFIG' || true

  echo
  echo "=== Auto-Direct runtime ==="
  for p in /tmp/mibr-direct-auto.state /tmp/mibr-direct-auto.heartbeat            /tmp/mibr-direct-auto-supervisor.pid /tmp/mibr-direct-auto-bridge.pid            /tmp/mibr-isotx2-gate.stats /tmp/mibr-direct-remux.status            /tmp/mibr-alt111-capture.status; do
    if [ -r "$p" ]; then
      echo "--- $p ---"
      cat "$p" 2>/dev/null || true
    fi
  done

  echo
  echo "=== recent AltScreen log ==="
  tail -400 /tmp/altscreen111.log 2>/dev/null || true

  echo
  echo "=== Auto-Direct master log ==="
  tail -240 "$DIRECT_ROOT/DIRECT-TS.log" 2>/dev/null || true

  echo
  echo "=== newest Auto-Direct run directories ==="
  if [ -d "$DIRECT_ROOT" ]; then
    ls -1dt "$DIRECT_ROOT"/*-auto-direct-* 2>/dev/null | awk 'NR<=4' |
    while read D; do
      [ -n "$D" ] || continue
      echo
      echo "--- RUN $D ---"
      [ -r "$D/SUMMARY.txt" ] && cat "$D/SUMMARY.txt" 2>/dev/null || true
      [ -r "$D/bridge.log" ] && {
        echo "--- bridge.log tail ---"
        tail -160 "$D/bridge.log" 2>/dev/null || true
      }
      [ -r "$D/direct-remux-final.status" ] && {
        echo "--- direct-remux-final.status ---"
        cat "$D/direct-remux-final.status" 2>/dev/null || true
      }
      [ -r "$D/altscreen111-post-bridge.log" ] && {
        echo "--- altscreen111-post-bridge.log tail ---"
        tail -120 "$D/altscreen111-post-bridge.log" 2>/dev/null || true
      }
    done
  fi
} > "$OUT"

sync 2>/dev/null || true
echo "GEN2_COLLECT_LOGS=PASS"
echo "report=$OUT"
[ -r "$FULL_ALT" ] && echo "full_altscreen_log=$FULL_ALT"
[ -r "$STATUS_SNAPSHOT" ] && echo "status_snapshot=$STATUS_SNAPSHOT"
[ -r "$REMUX_SNAPSHOT" ] && echo "remux_status_snapshot=$REMUX_SNAPSHOT"
[ -r "$CAPTURE_SNAPSHOT" ] && echo "capture_status_snapshot=$CAPTURE_SNAPSHOT"
