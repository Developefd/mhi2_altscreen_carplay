#!/bin/ksh
set -u

BASE=/net/mmx/fs/sda0/esd/carplay-test
ALT_LOG=/tmp/altscreen111.log
VC_LOG=/tmp/mibr-vc-view.log
KOMBI_LOG=/tmp/mibr-v4-direct-debug.log
GEN2_STATUS=/tmp/mibr-alt111-gen2.status
STREAM_STATE=/tmp/mibr-carplay111.state
DIRECT_STATE=/tmp/mibr-direct-auto.state
REMUX_STATUS=/tmp/mibr-direct-remux.status
CAPTURE_STATUS=/tmp/mibr-alt111-capture.status
VC_PROBE=/tmp/mibr-vc-view-probe.enabled
ACTIVE=/tmp/mibr-live-monitor.active
PIDFILE=/tmp/mibr-live-monitor.pid
STOPFILE=/tmp/mibr-live-monitor.stop
TIMEFILE=/tmp/mibr-live-monitor.seconds

SECONDS=0

now_human() {
    echo "t+${SECONDS}s"
}

session_stamp() {
    echo "pid$$"
}

line_count() {
    if [ -r "$1" ]; then
        awk 'END { print NR+0 }' "$1" 2>/dev/null
    else
        echo 0
    fi
}

append_compact() {
    echo "$1" >> "$JOURNAL"
}

append_raw() {
    echo "$1" >> "$RAW_JOURNAL"
}

emit() {
    TAG=$1
    shift
    append_compact "$(now_human) [$TAG] $*"
}

emit_raw() {
    TAG=$1
    shift
    append_raw "$(now_human) [$TAG] $*"
}

status_value() {
    KEY=$1
    [ -r "$GEN2_STATUS" ] || return 0
    awk -F= -v k="$KEY" '$1==k {print $2; exit}' "$GEN2_STATUS" 2>/dev/null
}

flat_status() {
    [ -r "$1" ] || return 0
    awk '{
        if (NR > 1) printf " "
        printf "%s", $0
    } END { if (NR > 0) printf "\n" }' "$1" 2>/dev/null
}

status_summary() {
    [ -r "$GEN2_STATUS" ] || return 0
    awk -F= '
        $1=="stream_gen" {stream=$2}
        $1=="codec_gen" {codec=$2}
        $1=="consumer_gen" {consumer=$2}
        $1=="config_valid" {config=$2}
        $1=="source_aus" {aus=$2}
        $1=="source_idrs" {idrs=$2}
        $1=="consumer_primed" {primed=$2}
        $1=="delivered_aus" {delivered=$2}
        $1=="dropped_aus" {dropped=$2}
        $1=="queue_count" {qcount=$2}
        $1=="queue_bytes" {qbytes=$2}
        $1=="resync_state" {resync=$2}
        $1=="d2_enabled" {d2=$2}
        $1=="d2_pending_sources" {d2p=$2}
        $1=="mode_sequence" {mseq=$2}
        $1=="mode_screen" {screen=$2}
        $1=="mode_main_audio" {audio=$2}
        $1=="mode_speech" {speech=$2}
        $1=="mode_speech_detail" {detail=$2}
        $1=="mode_phone" {phone=$2}
        $1=="mode_turns" {turns=$2}
        END {
            printf "stream=%s codec=%s consumer=%s cfg=%s aus=%s idr=%s delivered=%s dropped=%s q=%s/%s primed=%s resync=%s d2=%s/%s modeSeq=%s screen=%s audio=%s speech=%s/%s phone=%s turns=%s",
                stream,codec,consumer,config,aus,idrs,delivered,dropped,qcount,qbytes,primed,resync,d2,d2p,mseq,screen,audio,speech,detail,phone,turns
        }
    ' "$GEN2_STATUS" 2>/dev/null
}

append_snapshot() {
    SUMMARY=$(status_summary)
    if [ -n "$SUMMARY" ]; then
        emit SNAP "$SUMMARY"
        emit_raw SNAP "$SUMMARY"
    fi
    if [ -r /tmp/mibr-vc-view.state ]; then
        VCS=$(cat /tmp/mibr-vc-view.state 2>/dev/null)
        if [ -n "$VCS" ]; then
            emit SNAP-VC "$VCS"
            emit_raw SNAP-VC "$VCS"
        fi
    fi
    if [ -r "$STREAM_STATE" ]; then
        SS=$(cat "$STREAM_STATE" 2>/dev/null)
        [ -n "$SS" ] && emit SNAP-STREAM "state=$SS"
        [ -n "$SS" ] && emit_raw SNAP-STREAM "state=$SS"
    fi
    if [ -r "$DIRECT_STATE" ]; then
        DS=$(cat "$DIRECT_STATE" 2>/dev/null)
        [ -n "$DS" ] && emit SNAP-DIRECT "state=$DS"
        [ -n "$DS" ] && emit_raw SNAP-DIRECT "state=$DS"
    fi
    RS=$(flat_status "$REMUX_STATUS")
    if [ -n "$RS" ]; then
        emit SNAP-MOST "$RS"
        emit_raw SNAP-MOST "$RS"
    fi
    CS=$(flat_status "$CAPTURE_STATUS")
    if [ -n "$CS" ]; then
        emit SNAP-CAPTURE "$CS"
        emit_raw SNAP-CAPTURE "$CS"
    fi
}

OLDPID=
if [ -r "$PIDFILE" ]; then
    OLDPID=$(cat "$PIDFILE" 2>/dev/null)
fi
if [ -n "$OLDPID" ] && kill -0 "$OLDPID" 2>/dev/null; then
    echo "LIVE_MONITOR=ALREADY_RUNNING pid=$OLDPID"
    [ -r "$ACTIVE" ] && cat "$ACTIVE"
    exit 20
fi

STAMP=$(session_stamp)
JOURNAL="$BASE/live-telemetry-$STAMP.log"
RAW_JOURNAL="$BASE/live-telemetry-$STAMP.raw.log"

: > "$JOURNAL" || {
    echo "LIVE_MONITOR=FAIL cannot_create_journal=$JOURNAL"
    exit 21
}
: > "$RAW_JOURNAL" || {
    echo "LIVE_MONITOR=FAIL cannot_create_raw_journal=$RAW_JOURNAL"
    exit 22
}

rm -f "$STOPFILE"
echo "$$" > "$PIDFILE"
{
    echo "pid=$$"
    echo "journal=$JOURNAL"
    echo "raw_journal=$RAW_JOURNAL"
    echo "timefile=$TIMEFILE"
} > "$ACTIVE"

VC_PROBE_CREATED=0
if [ ! -e "$VC_PROBE" ]; then
    if : > "$VC_PROBE" 2>/dev/null; then
        VC_PROBE_CREATED=1
    fi
fi

echo "$SECONDS" > "$TIMEFILE"
emit SESSION "start pid=$$ compact=$JOURNAL raw=$RAW_JOURNAL"
emit_raw SESSION "start pid=$$ compact=$JOURNAL raw=$RAW_JOURNAL vc_probe_created=$VC_PROBE_CREATED"
append_snapshot

ALT_POS=$(line_count "$ALT_LOG")
VC_POS=$(line_count "$VC_LOG")
KOMBI_POS=$(line_count "$KOMBI_LOG")
LAST_STREAM_STATE=
LAST_DIRECT_STATE=
TICK=0

LAST_STREAM_GEN=$(status_value stream_gen)
LAST_CODEC_GEN=$(status_value codec_gen)
LAST_CONSUMER_GEN=$(status_value consumer_gen)
LAST_CONFIG=$(status_value config_valid)
LAST_PRIMED=$(status_value consumer_primed)
LAST_IDRS=$(status_value source_idrs)
LAST_DROPPED=$(status_value dropped_aus)
LAST_RESYNC=$(status_value resync_state)
LAST_MODE_SEQ=$(status_value mode_sequence)
LAST_SOURCE_AUS=$(status_value source_aus)
LAST_DELIVERED=$(status_value delivered_aus)
SOURCE_STALL_TICKS=0
DELIVERY_STALL_TICKS=0
SOURCE_STALLED=0
DELIVERY_STALLED=0

track_status_changes() {
    CUR_STREAM_GEN=$(status_value stream_gen)
    CUR_CODEC_GEN=$(status_value codec_gen)
    CUR_CONSUMER_GEN=$(status_value consumer_gen)
    CUR_CONFIG=$(status_value config_valid)
    CUR_PRIMED=$(status_value consumer_primed)
    CUR_IDRS=$(status_value source_idrs)
    CUR_DROPPED=$(status_value dropped_aus)
    CUR_RESYNC=$(status_value resync_state)
    CUR_MODE_SEQ=$(status_value mode_sequence)
    CUR_SOURCE_AUS=$(status_value source_aus)
    CUR_DELIVERED=$(status_value delivered_aus)

    if [ -n "$CUR_STREAM_GEN$CUR_CODEC_GEN$CUR_CONSUMER_GEN" ] &&        [ "$CUR_STREAM_GEN/$CUR_CODEC_GEN/$CUR_CONSUMER_GEN" != "$LAST_STREAM_GEN/$LAST_CODEC_GEN/$LAST_CONSUMER_GEN" ]; then
        emit GEN "stream $LAST_STREAM_GEN->$CUR_STREAM_GEN codec $LAST_CODEC_GEN->$CUR_CODEC_GEN consumer $LAST_CONSUMER_GEN->$CUR_CONSUMER_GEN"
    fi

    if [ -n "$CUR_CONFIG$CUR_PRIMED" ] && [ "$CUR_CONFIG/$CUR_PRIMED" != "$LAST_CONFIG/$LAST_PRIMED" ]; then
        emit PIPE "config $LAST_CONFIG->$CUR_CONFIG primed $LAST_PRIMED->$CUR_PRIMED"
    fi

    if [ -n "$CUR_IDRS" ] && [ "$CUR_IDRS" != "$LAST_IDRS" ]; then
        emit IDR "source_idrs $LAST_IDRS->$CUR_IDRS source_aus=$CUR_SOURCE_AUS"
    fi

    if [ -n "$CUR_DROPPED" ] && [ "$CUR_DROPPED" != "$LAST_DROPPED" ]; then
        emit DROP "dropped_aus $LAST_DROPPED->$CUR_DROPPED"
    fi

    if [ -n "$CUR_RESYNC" ] && [ "$CUR_RESYNC" != "$LAST_RESYNC" ]; then
        emit RESYNC "state $LAST_RESYNC->$CUR_RESYNC"
    fi

    if [ -n "$CUR_MODE_SEQ" ] && [ "$CUR_MODE_SEQ" != "$LAST_MODE_SEQ" ]; then
        MS=$(status_value mode_screen)
        MA=$(status_value mode_main_audio)
        SP=$(status_value mode_speech)
        SD=$(status_value mode_speech_detail)
        PH=$(status_value mode_phone)
        TU=$(status_value mode_turns)
        emit MODE "seq $LAST_MODE_SEQ->$CUR_MODE_SEQ screen=$MS audio=$MA speech=$SP/$SD phone=$PH turns=$TU"
    fi

    if [ -n "$CUR_SOURCE_AUS" ]; then
        if [ "$CUR_SOURCE_AUS" = "$LAST_SOURCE_AUS" ]; then
            SOURCE_STALL_TICKS=$((SOURCE_STALL_TICKS + 1))
        else
            if [ "$SOURCE_STALLED" -eq 1 ]; then
                emit FLOW "source resumed aus=$CUR_SOURCE_AUS"
            fi
            SOURCE_STALL_TICKS=0
            SOURCE_STALLED=0
        fi
        if [ "$SOURCE_STALL_TICKS" -ge 3 ] && [ "$SOURCE_STALLED" -eq 0 ]; then
            emit FLOW "source stalled >=3s aus=$CUR_SOURCE_AUS"
            SOURCE_STALLED=1
        fi
    fi

    if [ -n "$CUR_DELIVERED" ]; then
        if [ "$CUR_DELIVERED" = "$LAST_DELIVERED" ]; then
            DELIVERY_STALL_TICKS=$((DELIVERY_STALL_TICKS + 1))
        else
            if [ "$DELIVERY_STALLED" -eq 1 ]; then
                emit FLOW "delivery resumed delivered=$CUR_DELIVERED"
            fi
            DELIVERY_STALL_TICKS=0
            DELIVERY_STALLED=0
        fi
        if [ "$DELIVERY_STALL_TICKS" -ge 3 ] && [ "$DELIVERY_STALLED" -eq 0 ]; then
            emit FLOW "delivery stalled >=3s delivered=$CUR_DELIVERED"
            DELIVERY_STALLED=1
        fi
    fi

    LAST_STREAM_GEN=$CUR_STREAM_GEN
    LAST_CODEC_GEN=$CUR_CODEC_GEN
    LAST_CONSUMER_GEN=$CUR_CONSUMER_GEN
    LAST_CONFIG=$CUR_CONFIG
    LAST_PRIMED=$CUR_PRIMED
    LAST_IDRS=$CUR_IDRS
    LAST_DROPPED=$CUR_DROPPED
    LAST_RESYNC=$CUR_RESYNC
    LAST_MODE_SEQ=$CUR_MODE_SEQ
    LAST_SOURCE_AUS=$CUR_SOURCE_AUS
    LAST_DELIVERED=$CUR_DELIVERED
}

collector() {
    while [ ! -e "$STOPFILE" ]; do
        echo "$SECONDS" > "$TIMEFILE"
        ALT_NOW=$(line_count "$ALT_LOG")
        if [ "$ALT_NOW" -lt "$ALT_POS" ]; then
            emit CP "source log reset old=$ALT_POS new=$ALT_NOW"
            emit_raw ALT "source_log_reset old=$ALT_POS new=$ALT_NOW"
            ALT_POS=0
        fi
        if [ "$ALT_NOW" -gt "$ALT_POS" ]; then
            START=$((ALT_POS + 1))
            sed -n "${START},${ALT_NOW}p" "$ALT_LOG" 2>/dev/null |
            while IFS= read -r L; do
                emit_raw ALT "$L"
                case "$L" in
                    *"GEN2 FLIGHT MODES_CHANGED"*|                    *"GEN2 FLIGHT"*command=suggestUI*|                    *"GEN2 FLIGHT"*command=changeModes*|                    *"GEN2 FLIGHT"*command=modesChanged*|                    *"GEN2 FLIGHT"*command=showUI*|                    *"GEN2 FLIGHT"*command=stopUI*|                    *"GEN2 FLIGHT"*command=forceKeyFrame*|                    *"GEN2 FLIGHT"*command=setUpStreams*"111"*|                    *"GEN2 FLIGHT"*command=tearDownStreams*"111"*|                    *"GEN2 RESYNC"*|                    *"stream111 SETUP accepted"*|                    *"AltScreen stream 111 connected"*|                    *"stream111"*"disconnect"*|                    *"stream111 valid transactional video config"*|                    *"gen2 UI command dispatched type=4"*|                    *"gen2 UI completion type=4"*)
                        emit CP "$L"
                        ;;
                esac
            done
            ALT_POS=$ALT_NOW
        fi

        VC_NOW=$(line_count "$VC_LOG")
        if [ "$VC_NOW" -lt "$VC_POS" ]; then
            emit VC "source log reset old=$VC_POS new=$VC_NOW"
            emit_raw VC "source_log_reset old=$VC_POS new=$VC_NOW"
            VC_POS=0
        fi
        if [ "$VC_NOW" -gt "$VC_POS" ]; then
            START=$((VC_POS + 1))
            sed -n "${START},${VC_NOW}p" "$VC_LOG" 2>/dev/null |
            while IFS= read -r L; do
                [ -n "$L" ] && emit_raw VC "$L"
                [ -n "$L" ] && emit VC "$L"
            done
            VC_POS=$VC_NOW
        fi

        KOMBI_NOW=$(line_count "$KOMBI_LOG")
        if [ "$KOMBI_NOW" -lt "$KOMBI_POS" ]; then
            emit KOMBI "source log reset old=$KOMBI_POS new=$KOMBI_NOW"
            emit_raw KOMBI "source_log_reset old=$KOMBI_POS new=$KOMBI_NOW"
            KOMBI_POS=0
        fi
        if [ "$KOMBI_NOW" -gt "$KOMBI_POS" ]; then
            START=$((KOMBI_POS + 1))
            sed -n "${START},${KOMBI_NOW}p" "$KOMBI_LOG" 2>/dev/null |
            while IFS= read -r L; do
                [ -n "$L" ] && emit_raw KOMBI "$L"
                case "$L" in
                    *"dsiUpdate raw="*|                    *"policyChange raw="*|                    *"visibleStep"*|                    *"rateStep"*|                    *"setDataFrameRate="*|                    *"updateNavigationMap"*|                    *"updateDisplayManagement"*)
                        emit KOMBI "$L"
                        ;;
                esac
            done
            KOMBI_POS=$KOMBI_NOW
        fi

        if [ -r "$STREAM_STATE" ]; then
            CUR_STREAM=$(cat "$STREAM_STATE" 2>/dev/null)
            if [ "$CUR_STREAM" != "$LAST_STREAM_STATE" ]; then
                emit STREAM "state=$CUR_STREAM"
                emit_raw STREAM "state=$CUR_STREAM"
                LAST_STREAM_STATE=$CUR_STREAM
            fi
        fi

        if [ -r "$DIRECT_STATE" ]; then
            CUR_DIRECT=$(cat "$DIRECT_STATE" 2>/dev/null)
            if [ "$CUR_DIRECT" != "$LAST_DIRECT_STATE" ]; then
                emit DIRECT "state=$CUR_DIRECT"
                emit_raw DIRECT "state=$CUR_DIRECT"
                LAST_DIRECT_STATE=$CUR_DIRECT
            fi
        fi

        track_status_changes

        TICK=$((TICK + 1))
        if [ $((TICK % 2)) -eq 0 ]; then
            SUMMARY=$(status_summary)
            [ -n "$SUMMARY" ] && emit_raw STAT "$SUMMARY"
            RS=$(flat_status "$REMUX_STATUS")
            [ -n "$RS" ] && emit_raw MOST "$RS"
            CS=$(flat_status "$CAPTURE_STATUS")
            [ -n "$CS" ] && emit_raw CAPTURE "$CS"
        fi

        sleep 1
    done
}

COLLECTOR_PID=
TAIL_PID=

cleanup() {
    trap - 0 1 2 15
    : > "$STOPFILE" 2>/dev/null || true
    if [ -n "${COLLECTOR_PID:-}" ]; then
        kill "$COLLECTOR_PID" 2>/dev/null || true
        wait "$COLLECTOR_PID" 2>/dev/null || true
    fi
    emit SESSION "stop pid=$$"
    emit_raw SESSION "stop pid=$$"
    if [ -n "${TAIL_PID:-}" ]; then
        sleep 1
        kill "$TAIL_PID" 2>/dev/null || true
        wait "$TAIL_PID" 2>/dev/null || true
    fi
    if [ "$VC_PROBE_CREATED" -eq 1 ]; then
        rm -f "$VC_PROBE"
    fi
    rm -f "$PIDFILE" "$ACTIVE" "$STOPFILE" "$TIMEFILE"
    echo
    echo "LIVE_MONITOR=STOPPED"
    echo "compact=$JOURNAL"
    echo "raw=$RAW_JOURNAL"
}

trap cleanup 0 1 2 15

collector &
COLLECTOR_PID=$!

tail -f "$JOURNAL" &
TAIL_PID=$!

echo
echo "LIVE_MONITOR=RUNNING"
echo "compact=$JOURNAL"
echo "raw=$RAW_JOURNAL"
echo "Screen output is filtered; the raw journal keeps the complete session detail."
echo "Timeline uses relative QNX-safe timestamps: t+Ns from monitor start."
echo "Commands: /snapshot  /paths  /help  /q"
echo "Recommended second SSH pane: ./gen2_live_mark.sh --loop"
echo

while IFS= read -r NOTE; do
    case "$NOTE" in
        "")
            ;;
        /q|/quit)
            break
            ;;
        /help)
            echo "Any text = timestamped NOTE in compact + raw journal"
            echo "/snapshot = append current GEN2 + VC state"
            echo "/paths = show compact/raw journal paths"
            echo "/q = stop monitor"
            ;;
        /paths)
            echo "compact=$JOURNAL"
            echo "raw=$RAW_JOURNAL"
            ;;
        /snapshot)
            emit NOTE "manual snapshot requested"
            emit_raw NOTE "manual snapshot requested"
            append_snapshot
            ;;
        *)
            emit NOTE "$NOTE"
            emit_raw NOTE "$NOTE"
            ;;
    esac
done

exit 0
