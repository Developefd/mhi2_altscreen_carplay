#!/bin/ksh
echo "=== GEN2 FAST REBOOT ==="
sync
sync
sync
echo "FAST_REBOOT=NOW"
on -f rcc /usr/apps/mib2_ioc_flash fastReboot
