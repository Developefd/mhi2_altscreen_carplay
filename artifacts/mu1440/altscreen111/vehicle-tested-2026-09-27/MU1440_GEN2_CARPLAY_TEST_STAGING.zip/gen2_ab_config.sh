#!/bin/ksh
set -u

MAP=/mnt/app/root/mibr-carplay111-url-map.enabled
NAV_SURFACE=/mnt/app/root/mibr-carplay111-nav.surface
VOLATILE_SURFACE=/tmp/mibr-alt111-url-mode
B26_ON=/mnt/app/root/mibr-carplay111-bit26.force-on
B26_OFF=/mnt/app/root/mibr-carplay111-bit26.force-off
RW=0

app_rw(){
    [ "$RW" -eq 1 ] && return 0
    mount -uw /mnt/app 2>/dev/null || {
        echo "GEN2_AB=FAIL_MOUNT_APP_RW"
        exit 10
    }
    RW=1
}

app_ro(){
    if [ "$RW" -eq 1 ]; then
        sync 2>/dev/null || true
        mount -ur /mnt/app 2>/dev/null || true
        RW=0
    fi
}
trap app_ro 0 1 2 15

write_marker(){
    : > "$1" || { echo "GEN2_AB=FAIL path=$1"; exit 1; }
}

write_value(){
    target=$1
    value=$2
    tmp="$target.tmp.$$"
    printf '%s\n' "$value" > "$tmp" || {
        rm -f "$tmp" 2>/dev/null || true
        echo "GEN2_AB=FAIL path=$target"
        exit 1
    }
    mv "$tmp" "$target" || {
        rm -f "$tmp" 2>/dev/null || true
        echo "GEN2_AB=FAIL path=$target"
        exit 1
    }
}

surface(){
    if [ -r "$VOLATILE_SURFACE" ]; then
        v=$(sed -n '1{s/[[:space:]]*$//;p;}' "$VOLATILE_SURFACE" 2>/dev/null)
        case "$v" in base|map|instructioncard) echo "$v"; return ;; esac
    fi
    if [ -r "$NAV_SURFACE" ]; then
        v=$(sed -n '1{s/[[:space:]]*$//;p;}' "$NAV_SURFACE" 2>/dev/null)
        case "$v" in base|map|instructioncard) echo "$v"; return ;; esac
    fi
    [ -r "$MAP" ] && echo map || echo base
}

show_status(){
    case "$(surface)" in
        map) echo "url=maps:/car/instrumentcluster/map" ;;
        instructioncard) echo "url=maps:/car/instrumentcluster/instructioncard" ;;
        *) echo "url=maps:/car/instrumentcluster" ;;
    esac

    if [ -r "$B26_ON" ]; then
        echo "bit26=force-on"
    elif [ -r "$B26_OFF" ]; then
        echo "bit26=force-off"
    else
        echo "bit26=stock"
    fi
}

case "${1:-status}" in
    status)
        show_status
        ;;
    url)
        app_rw
        case "${2:-}" in
            base)
                rm -f "$MAP" "$VOLATILE_SURFACE" 2>/dev/null || true
                write_value "$NAV_SURFACE" base
                ;;
            map)
                rm -f "$VOLATILE_SURFACE" 2>/dev/null || true
                write_marker "$MAP"
                write_value "$NAV_SURFACE" map
                ;;
            *)
                app_ro
                echo "usage: $0 url {base|map}"
                exit 2
                ;;
        esac
        app_ro
        show_status
        echo "GEN2_AB=PASS reconnect_carplay=1"
        ;;
    bit26)
        app_rw
        case "${2:-}" in
            stock)
                rm -f "$B26_ON" "$B26_OFF"
                ;;
            on)
                rm -f "$B26_OFF"
                write_marker "$B26_ON"
                ;;
            off)
                rm -f "$B26_ON"
                write_marker "$B26_OFF"
                ;;
            *)
                app_ro
                echo "usage: $0 bit26 {stock|on|off}"
                exit 2
                ;;
        esac
        app_ro
        show_status
        echo "GEN2_AB=PASS reconnect_carplay=1"
        ;;
    baseline)
        app_rw
        rm -f "$MAP" "$B26_ON" "$B26_OFF" "$VOLATILE_SURFACE"
        write_value "$NAV_SURFACE" base
        app_ro
        show_status
        echo "GEN2_AB=PASS reconnect_carplay=1"
        ;;
    *)
        echo "usage: $0 [status|baseline|url {base|map}|bit26 {stock|on|off}]"
        exit 2
        ;;
esac
