#!/bin/ksh
set -u

BASE=/net/mmx/fs/sda0/esd/carplay-test
BIN=$BASE/libaltscreen111-gen2.so
SHAFILE=$BASE/libaltscreen111-gen2.so.sha256
AIRPLAY=/mnt/app/eso/lib/libairplay.so
EXPECTED_AIRPLAY=193a4fd9101ec2aa05E7159CFA307B96500810D379CA74A194F172ADC13A46B5
CFG=/mnt/system/etc/eso/production/smartphone_integrator.json
HOOK=/mnt/app/eso/lib/libmibr_carplay111.so
BACKDIR=/mnt/app/root/mibr-gen2-backup
BACKUP=$BACKDIR/libmibr_carplay111.pre-gen2.so
BACKUP_SHA=$BACKDIR/libmibr_carplay111.pre-gen2.so.sha256
INSTALLED_SHA=$BACKDIR/installed-gen2.sha256
LEGACY_BACKUP=/mnt/app/eso/lib/libmibr_carplay111.so.pre-gen2
LEGACY_BACKUP_SHA=$LEGACY_BACKUP.sha256
TMP=$HOOK.gen2-new.$$

find_sha(){
  for p in /mnt/app/root/altscreen-u2/bin/sha256sum /net/mmx/fs/sda0/esd/bin/sha256sum /usr/bin/sha256sum /bin/sha256sum; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  command -v sha256sum 2>/dev/null && return 0
  return 1
}
SHA=$(find_sha) || { echo "GEN2_PREPARE=FAIL_NO_SHA256"; exit 2; }
hash_file(){ "$SHA" "$1" 2>/dev/null | awk '{print $1; exit}'; }
cleanup(){ rm -f "$TMP" 2>/dev/null || true; }
trap cleanup 0 1 2 15

echo "=== GEN2 PREPARE ==="

[ -r "$BIN" ] || { echo "GEN2_PREPARE=FAIL_NO_BINARY"; exit 10; }
[ -r "$SHAFILE" ] || { echo "GEN2_PREPARE=FAIL_NO_BINARY_SHA"; exit 11; }
[ -r "$HOOK" ] || { echo "GEN2_PREPARE=FAIL_NO_CURRENT_HOOK"; exit 12; }

EXPECTED_BIN=$(awk '{print $1; exit}' "$SHAFILE")
ACTUAL_BIN=$(hash_file "$BIN")
[ -n "$EXPECTED_BIN" ] && [ "$EXPECTED_BIN" = "$ACTUAL_BIN" ] || {
  echo "GEN2_PREPARE=FAIL_BINARY_HASH expected=$EXPECTED_BIN actual=$ACTUAL_BIN"
  exit 13
}

AIR_SHA=$(hash_file "$AIRPLAY")
# hash output is normally lowercase; compare normalized known value
echo "$AIR_SHA" | grep -qi '^193a4fd9101ec2aa05e7159cfa307b96500810d379ca74a194f172adc13a46b5$' || {
  echo "GEN2_PREPARE=FAIL_AIRPLAY_HASH actual=$AIR_SHA"
  exit 14
}

grep -q "LD_PRELOAD=$HOOK" "$CFG" 2>/dev/null || {
  echo "GEN2_PREPARE=FAIL_PRELOAD_NOT_CONFIGURED"
  exit 15
}

CURRENT=$(hash_file "$HOOK")
echo "current_hook_sha256=$CURRENT"
echo "gen2_hook_sha256=$ACTUAL_BIN"

mount -uw /mnt/app 2>/dev/null || { echo "GEN2_PREPARE=FAIL_MOUNT_APP_RW"; exit 16; }
mkdir -p "$BACKDIR" || {
  mount -ur /mnt/app 2>/dev/null || true
  echo "GEN2_PREPARE=FAIL_BACKUP_DIR"
  exit 17
}

if [ ! -r "$BACKUP" ]; then
  # Migrate the one legacy carplay-test backup namespace if it exists and its
  # sidecar hash proves the bytes. This prevents a prior GEN2 binary from being
  # mistaken for the original pre-GEN2 state after the namespace unification.
  if [ -r "$LEGACY_BACKUP" ] && [ -r "$LEGACY_BACKUP_SHA" ]; then
    LB=$(hash_file "$LEGACY_BACKUP")
    LR=$(awk '{print $1; exit}' "$LEGACY_BACKUP_SHA" 2>/dev/null)
    if [ -n "$LR" ] && [ "$LB" = "$LR" ]; then
      cp "$LEGACY_BACKUP" "$BACKUP" || {
        mount -ur /mnt/app 2>/dev/null || true
        echo "GEN2_PREPARE=FAIL_LEGACY_BACKUP_MIGRATE"
        exit 18
      }
      chmod 755 "$BACKUP" 2>/dev/null || true
      echo "$LB  $BACKUP" > "$BACKUP_SHA" || {
        mount -ur /mnt/app 2>/dev/null || true
        echo "GEN2_PREPARE=FAIL_BACKUP_SHA_CREATE"
        exit 18
      }
      echo "migrated_legacy_pre_gen2_backup=$LEGACY_BACKUP"
    else
      mount -ur /mnt/app 2>/dev/null || true
      echo "GEN2_PREPARE=FAIL_LEGACY_BACKUP_HASH expected=$LR actual=$LB"
      exit 18
    fi
  else
    cp "$HOOK" "$BACKUP" || {
      mount -ur /mnt/app 2>/dev/null || true
      echo "GEN2_PREPARE=FAIL_BACKUP_COPY"
      exit 18
    }
    chmod 755 "$BACKUP" 2>/dev/null || true
    B=$(hash_file "$BACKUP")
    echo "$B  $BACKUP" > "$BACKUP_SHA" || {
      mount -ur /mnt/app 2>/dev/null || true
      echo "GEN2_PREPARE=FAIL_BACKUP_SHA_CREATE"
      exit 18
    }
  fi
  sync
  B=$(hash_file "$BACKUP")
  echo "created_pre_gen2_backup=$BACKUP"
  echo "backup_sha256=$B"
else
  B=$(hash_file "$BACKUP")
  R=$(awk '{print $1; exit}' "$BACKUP_SHA" 2>/dev/null)
  [ -z "$R" ] || [ "$R" = "$B" ] || {
    mount -ur /mnt/app 2>/dev/null || true
    echo "GEN2_PREPARE=FAIL_BACKUP_HASH expected=$R actual=$B"
    exit 18
  }
  if [ -z "$R" ]; then
    echo "$B  $BACKUP" > "$BACKUP_SHA" || {
      mount -ur /mnt/app 2>/dev/null || true
      echo "GEN2_PREPARE=FAIL_BACKUP_SHA_CREATE"
      exit 18
    }
    sync
    echo "created_missing_backup_sha=$BACKUP_SHA"
  fi
  echo "using_existing_pre_gen2_backup=$BACKUP"
  echo "backup_sha256=$B"
fi

# Refuse to overwrite an unrelated post-backup hook. A previous GEN2 hash is
# accepted only when it was explicitly recorded by this unified backup authority.
PREVIOUS_GEN2=$(awk '{print $1; exit}' "$INSTALLED_SHA" 2>/dev/null)
if [ "$CURRENT" != "$B" ] && [ "$CURRENT" != "$ACTUAL_BIN" ]; then
  if [ -z "$PREVIOUS_GEN2" ] || [ "$CURRENT" != "$PREVIOUS_GEN2" ]; then
    mount -ur /mnt/app 2>/dev/null || true
    echo "GEN2_PREPARE=FAIL_UNKNOWN_CURRENT_HOOK current=$CURRENT backup=$B gen2=$ACTUAL_BIN previous_gen2=$PREVIOUS_GEN2"
    exit 19
  fi
fi

cp "$BIN" "$TMP" &&
chmod 755 "$TMP" &&
mv "$TMP" "$HOOK"
RC=$?
sync
sync
mount -ur /mnt/app 2>/dev/null || true
[ $RC -eq 0 ] || { echo "GEN2_PREPARE=FAIL_INSTALL"; exit 20; }

FINAL=$(hash_file "$HOOK")
[ "$FINAL" = "$ACTUAL_BIN" ] || {
  echo "GEN2_PREPARE=FAIL_VERIFY expected=$ACTUAL_BIN actual=$FINAL"
  exit 21
}

if mount -uw /mnt/app 2>/dev/null; then
  echo "$FINAL" > "$INSTALLED_SHA"
  sync
  mount -ur /mnt/app 2>/dev/null || true
else
  echo "GEN2_PREPARE=FAIL_RECORD_INSTALLED_HASH"
  exit 22
fi

echo "GEN2_PREPARE=PASS"
echo "installed_sha256=$FINAL"
echo "backup_sha256=$B"
echo "REBOOT_REQUIRED=YES"
echo "NEXT=./gen2_reboot_fast.sh"
