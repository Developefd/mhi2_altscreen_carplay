#!/bin/ksh
set -u

BASE=/net/mmx/fs/sda0/esd/carplay-test
SRC=$BASE/direct-ts-remux-gen2
DST=/mnt/app/root/altscreen-u2/bin/direct-ts-remux
BACKDIR=/mnt/app/root/mibr-gen2-backup
BACKUP=$BACKDIR/direct-ts-remux.pre-live-status
BACKUP_SHA=$BACKUP.sha256
TMP=$DST.gen2-new.$$

find_sha(){
  for p in /mnt/app/root/altscreen-u2/bin/sha256sum /net/mmx/fs/sda0/esd/bin/sha256sum /usr/bin/sha256sum /bin/sha256sum; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  command -v sha256sum 2>/dev/null && return 0
  return 1
}
SHA=$(find_sha) || { echo "GEN2_REMUX_INSTALL=FAIL_NO_SHA256"; exit 2; }
hash_file(){ "$SHA" "$1" 2>/dev/null | awk '{print $1; exit}'; }
cleanup(){ rm -f "$TMP" 2>/dev/null || true; }
trap cleanup 0 1 2 15

[ -x "$SRC" ] || { echo "GEN2_REMUX_INSTALL=FAIL_NO_SOURCE"; exit 10; }
[ -r "$DST" ] || { echo "GEN2_REMUX_INSTALL=FAIL_NO_TARGET"; exit 11; }

RUNNING=$(pidin ar 2>/dev/null | awk '/[d]irect-ts-remux/ {print $1; exit}')
if [ -n "$RUNNING" ]; then
  echo "GEN2_REMUX_INSTALL=REFUSE_RUNNING pid=$RUNNING"
  echo "Disconnect/stop the current DIRECT session and retry."
  exit 12
fi

mount -uw /mnt/app 2>/dev/null || { echo "GEN2_REMUX_INSTALL=FAIL_MOUNT_APP_RW"; exit 13; }
mkdir -p "$BACKDIR" || { mount -ur /mnt/app 2>/dev/null || true; exit 14; }

if [ ! -r "$BACKUP" ]; then
  cp "$DST" "$BACKUP" || { mount -ur /mnt/app 2>/dev/null || true; exit 15; }
  chmod 755 "$BACKUP" 2>/dev/null || true
  B=$(hash_file "$BACKUP")
  echo "$B  $BACKUP" > "$BACKUP_SHA" || { mount -ur /mnt/app 2>/dev/null || true; exit 16; }
else
  B=$(hash_file "$BACKUP")
  R=$(awk '{print $1; exit}' "$BACKUP_SHA" 2>/dev/null)
  [ -z "$R" ] || [ "$R" = "$B" ] || {
    mount -ur /mnt/app 2>/dev/null || true
    echo "GEN2_REMUX_INSTALL=FAIL_BACKUP_HASH expected=$R actual=$B"
    exit 17
  }
fi

SRC_SHA=$(hash_file "$SRC")
cp "$SRC" "$TMP" && chmod 755 "$TMP" && mv "$TMP" "$DST"
RC=$?
sync 2>/dev/null || true
mount -ur /mnt/app 2>/dev/null || true
[ "$RC" -eq 0 ] || { echo "GEN2_REMUX_INSTALL=FAIL_COPY"; exit 18; }

DST_SHA=$(hash_file "$DST")
[ "$DST_SHA" = "$SRC_SHA" ] || {
  echo "GEN2_REMUX_INSTALL=FAIL_VERIFY expected=$SRC_SHA actual=$DST_SHA"
  exit 19
}

echo "GEN2_REMUX_INSTALL=PASS"
echo "installed_sha256=$DST_SHA"
echo "backup_sha256=$B"
echo "REBOOT_REQUIRED=NO"
