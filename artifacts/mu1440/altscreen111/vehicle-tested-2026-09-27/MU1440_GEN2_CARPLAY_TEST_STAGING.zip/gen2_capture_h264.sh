#!/bin/ksh
set -u

BASE=/net/mmx/fs/sda0/esd/carplay-test
BIN=$BASE/gen2-h264-capture
HOST=127.0.0.1
PORT=19821
ACTIVE=/tmp/mibr-gen2-h264-capture.active
PIDFILE=/tmp/mibr-gen2-h264-capture.pid
STATUS=/tmp/mibr-alt111-capture.status
GEN2_STATUS=/tmp/mibr-alt111-gen2.status
DIRECT_STATE=/tmp/mibr-direct-auto.state

active_pid(){
  [ -r "$PIDFILE" ] && cat "$PIDFILE" 2>/dev/null
}

show_status(){
  P=$(active_pid)
  if [ -n "${P:-}" ] && kill -0 "$P" 2>/dev/null; then
    echo "GEN2_H264_CAPTURE=RUNNING pid=$P"
  else
    echo "GEN2_H264_CAPTURE=STOPPED"
  fi
  [ -r "$ACTIVE" ] && cat "$ACTIVE" 2>/dev/null || true
  [ -r "$STATUS" ] && {
    echo "--- capture mirror ---"
    cat "$STATUS" 2>/dev/null || true
  }
}

case "${1:-status}" in
  start)
    [ -x "$BIN" ] || { echo "GEN2_H264_CAPTURE=FAIL_NO_HELPER $BIN"; exit 10; }

    CFG=$(awk -F= '$1=="config_valid"{print $2; exit}' "$GEN2_STATUS" 2>/dev/null)
    PRIMED=$(awk -F= '$1=="consumer_primed"{print $2; exit}' "$GEN2_STATUS" 2>/dev/null)
    DIRECT=$(cat "$DIRECT_STATE" 2>/dev/null)
    if [ "$CFG" != "1" ] || [ "$PRIMED" != "1" ] || [ "$DIRECT" != "direct" ]; then
      echo "GEN2_H264_CAPTURE=WAIT_PIPELINE cfg=${CFG:-?} primed=${PRIMED:-?} direct=${DIRECT:-?}"
      echo "Start only after wired CarPlay is connected and Auto-Direct is direct."
      exit 13
    fi

    P=$(active_pid)
    if [ -n "${P:-}" ] && kill -0 "$P" 2>/dev/null; then
      echo "GEN2_H264_CAPTURE=ALREADY_RUNNING pid=$P"
      [ -r "$ACTIVE" ] && cat "$ACTIVE"
      exit 0
    fi

    STAMP="pid$$"
    OUT="$BASE/stream111-prets-$STAMP.h264"
    LOG="$BASE/stream111-prets-$STAMP.capture.log"
    : > "$LOG" || { echo "GEN2_H264_CAPTURE=FAIL_LOG"; exit 11; }

    "$BIN" "$HOST" "$PORT" "$OUT" > "$LOG" 2>&1 &
    P=$!
    echo "$P" > "$PIDFILE"
    {
      echo "P=$P"
      echo "OUT=$OUT"
      echo "LOG=$LOG"
      echo "CAPTURE_PORT=$PORT"
    } > "$ACTIVE"

    sleep 1
    if ! kill -0 "$P" 2>/dev/null; then
      echo "GEN2_H264_CAPTURE=FAIL_CONNECT"
      cat "$LOG" 2>/dev/null || true
      rm -f "$PIDFILE" "$ACTIVE"
      exit 12
    fi

    echo "GEN2_H264_CAPTURE=RUNNING pid=$P"
    echo "output=$OUT"
    echo "log=$LOG"
    echo "NOTE=connection requests one fresh IDR, then capture is passive"
    ;;
  stop)
    P=$(active_pid)
    OUT=
    LOG=
    if [ -r "$ACTIVE" ]; then
      . "$ACTIVE"
    fi
    if [ -n "${P:-}" ] && kill -0 "$P" 2>/dev/null; then
      kill "$P" 2>/dev/null || true
      sleep 1
      kill -0 "$P" 2>/dev/null && kill -9 "$P" 2>/dev/null || true
    fi
    [ -n "${OUT:-}" ] && [ -r "$STATUS" ] && cp "$STATUS" "$OUT.status.txt" 2>/dev/null || true
    sync 2>/dev/null || true
    echo "GEN2_H264_CAPTURE=STOPPED"
    [ -n "${OUT:-}" ] && {
      SZ=$(ls -ln "$OUT" 2>/dev/null | awk '{print $5; exit}')
      echo "output=$OUT"
      echo "bytes=${SZ:-0}"
    }
    [ -n "${LOG:-}" ] && echo "log=$LOG"
    rm -f "$PIDFILE" "$ACTIVE"
    ;;
  status)
    show_status
    ;;
  *)
    echo "usage: $0 start|stop|status"
    exit 64
    ;;
esac
