MU1440 CarPlay AltScreen GEN2 - carplay-test staging

Staging directory on the SD card:
  /net/mmx/fs/sda0/esd/carplay-test

This is the same style as the recent Run143 vehicle tests.
Existing run113/run116/run117/run127/run143 files in carplay-test are NOT replaced.

Copy these GEN2 files into the existing carplay-test directory:
  libaltscreen111-gen2.so
  libaltscreen111-gen2.so.sha256
  gen2_prereq.sh
  gen2_prepare.sh
  gen2_reboot_fast.sh
  gen2_verify.sh
  gen2_status.sh
  gen2_reacquire.sh
  gen2_resync.sh
  gen2_collect_logs.sh
  gen2_live_monitor.sh
  gen2_live_mark.sh
  gen2_capture_h264.sh
  gen2_install_remux_status.sh
  gen2-h264-capture
  direct-ts-remux-gen2
  gen2_ab_config.sh
  gen2_nav_config.sh
  gen2_restore.sh

First test:
  cd /net/mmx/fs/sda0/esd/carplay-test
  chmod 755 gen2_*.sh libaltscreen111-gen2.so
  ./gen2_prereq.sh
  ./gen2_prepare.sh
  ./gen2_reboot_fast.sh

After reboot and wired CarPlay connection:
  cd /net/mmx/fs/sda0/esd/carplay-test
  ./gen2_verify.sh
  ./gen2_status.sh

Then start Apple Maps. If the VC works, switch to Waze/Google without
disconnecting the cable. If the previous image remains:
  ./gen2_status.sh
  ./gen2_reacquire.sh
  ./gen2_collect_logs.sh
  cat gen2-last-report.txt


Live correlated telemetry (MobaXterm / SSH MVP):
  ./gen2_live_monitor.sh

The monitor enables the passive VC probe for the session and starts from the
current end of the existing logs. It writes TWO synchronized journals:

  live-telemetry-YYYYMMDD-HHMMSS.log
    Compact operator view. This is what is tailed on screen.

  live-telemetry-YYYYMMDD-HHMMSS.raw.log
    Full session evidence. All new CarPlay, VC and Kombi source-log lines plus
    periodic complete GEN2 status snapshots are retained here.

The compact live view is deliberately quiet. It shows only:
  [NOTE]   your timestamped comments
  [CP]     relevant lifecycle/control events (modesChanged, Stream111,
           suggestUI, VideoConfig, keyframe/recovery)
  [VC]     changed passive mostkombi state tuples
  [KOMBI]  raw DSI data-rate and map/display transition callbacks
  [MODE]   mode-sequence changes
  [IDR]    fresh source-IDR events
  [GEN]    stream/codec/consumer generation changes
  [PIPE]   config/consumer-primed changes
  [FLOW]   source or delivery stalled/resumed (after >=3 s)
  [DROP]   dropped-AU counter changes
  [RESYNC] recovery-state changes
  [STREAM] / [DIRECT] state changes

Continuous 2-second counter snapshots are kept only in the .raw.log, not printed
to the live screen. These now include the direct-remux/MOST heartbeat from
/tmp/mibr-direct-remux.status and the pre-TS capture mirror status. Use /snapshot
when you want the complete current state in the compact timeline.

While it is running, simply type a comment in the same terminal and press Enter,
for example:
  Apple Maps route started
  switch to Waze now
  VC mode 2 - map background
  VC mode 3 - no map
  frozen frame observed

Useful monitor commands:
  /snapshot
  /paths
  /help
  /q

Recommended MobaXterm setup is two SSH panes:
  pane 1: ./gen2_live_monitor.sh
  pane 2: ./gen2_live_mark.sh --loop

The second pane stays at comment>. Every note is written to BOTH compact and raw
journals and appears immediately in pane 1. This preserves exact operator-event
ordering without flooding the screen with the full diagnostic stream.

Pre-TS H.264 capture for the next evidence run:
  ./gen2_capture_h264.sh start

This records the exact Annex-B H.264 handed to the production remux path into:
  stream111-prets-pidNNN.h264

The capture uses a separate diagnostic mirror on 127.0.0.1:19821, so it does not
steal the production 19820 consumer. Capture connection requests ONE fresh IDR so
the saved file starts decodably, then it is passive. Stop it after the test with:
  ./gen2_capture_h264.sh stop

Install the telemetry-enabled direct remux while no direct-ts-remux process is running:
  ./gen2_install_remux_status.sh

That transport update does not require a reboot. The new GEN2 interposer/capture mirror
does require the normal gen2_prepare.sh + reboot boundary.

Runtime A/B controls (no rebuild):
  ./gen2_ab_config.sh status
  ./gen2_ab_config.sh url base
  ./gen2_ab_config.sh url map
  ./gen2_ab_config.sh bit26 stock
  ./gen2_ab_config.sh bit26 on
  ./gen2_ab_config.sh bit26 off
  ./gen2_ab_config.sh baseline

Reconnect CarPlay after changing a value. Baseline is URL=base and bit26=stock.
Bit26 on/off modifies the classic AirPlay root features bit 26 only; keep it
at stock unless running that isolated diagnostic.

Navigation composition / appearance controls (persistent, no rebuild):
  ./gen2_nav_config.sh status

One-command live profile switch:
  ./gen2_nav_config.sh use base-right

'use' persists the selected profile, then performs the serialized same-stream
transition:
  stopUI -> showUI(new URL/query) -> forceKeyFrame

This intentionally requests a fresh source IDR after every live profile switch;
Stream 111 itself is not rebuilt.

Individual persistent switches:
  ./gen2_nav_config.sh surface base
  ./gen2_nav_config.sh eta yes
  ./gen2_nav_config.sh speed user
  ./gen2_nav_config.sh compass user
  ./gen2_nav_config.sh maneuver right
  ./gen2_nav_config.sh enable
  ./gen2_nav_config.sh apply

Individual LIVE switches (persist + re-show + fresh keyframe in one command):
  ./gen2_nav_config.sh live surface map
  ./gen2_nav_config.sh live eta no
  ./gen2_nav_config.sh live speed user
  ./gen2_nav_config.sh live compass no
  ./gen2_nav_config.sh live maneuver right

Profiles:
  stock          bare maps:/car/instrumentcluster; query parameters disabled
  base-rich      base + ETA/speed-limit/compass, no forced maneuver alignment
  base-right     base + ETA/speed-limit/compass + rightAligned maneuver
  base-left      same with leftAligned maneuver
  base-top       same with topAligned maneuver
  map-rich       /map + ETA/speed-limit/compass
  map-clean      /map with ETA/speed-limit/compass explicitly disabled
  maneuver-only  bare /instructioncard

The external switches live under /mnt/app/root and survive reboot. Query
parameters are deliberately suppressed for /instructioncard to match observed
Apple Simulator behavior. Plain 'profile' changes configuration only; 'use'
changes it and applies it live. Keep apply/use separate from isolated D1/D2
recovery experiments so the test variable remains unambiguous.

Navigation composition / appearance controls (persistent, no rebuild):
  ./gen2_nav_config.sh status
  ./gen2_nav_config.sh profile base-right
  ./gen2_nav_config.sh apply

Individual switches:
  ./gen2_nav_config.sh surface base
  ./gen2_nav_config.sh eta yes
  ./gen2_nav_config.sh speed user
  ./gen2_nav_config.sh compass user
  ./gen2_nav_config.sh maneuver right
  ./gen2_nav_config.sh enable
  ./gen2_nav_config.sh apply

Profiles:
  stock          bare maps:/car/instrumentcluster; query parameters disabled
  base-rich      base + ETA/speed-limit/compass, no forced maneuver alignment
  base-right     base + ETA/speed-limit/compass + rightAligned maneuver
  base-left      same with leftAligned maneuver
  base-top       same with topAligned maneuver
  map-rich       /map + ETA/speed-limit/compass
  map-clean      /map with ETA/speed-limit/compass explicitly disabled
  maneuver-only  bare /instructioncard

The persistent files are external switches under /mnt/app/root. Query parameters
are deliberately suppressed for /instructioncard to match observed Apple
Simulator behavior. Changes are inert until the next showUI. 'apply' uses the
existing serialized same-stream reacquire path (STOP -> SHOW -> forceKeyFrame);
it does not rebuild Stream111. Keep this separate from isolated D1/D2 recovery
experiments so the test variable remains unambiguous.

Candidate D manual same-stream IDR recovery (automatic arming is deliberately OFF):
  ./gen2_resync.sh status
  ./gen2_resync.sh on
  # reproduce a stale/frozen VC while Stream111 remains alive
  ./gen2_resync.sh arm
  ./gen2_resync.sh status
  ./gen2_resync.sh off

The arm operation does NOT stop/show/rebuild Stream111. It requests the existing
AirPlay forceKeyFrame/ScreenRestartBitstream path and considers recovery complete
only when the source IDR counter advances. Retries use 1s -> 2s -> 4s -> 4s.
Do not leave the manual feature enabled outside this isolated diagnostic.

Rollback:
  ./gen2_restore.sh
  ./gen2_reboot_fast.sh

Persistent mutation:
  only /mnt/app/eso/lib/libmibr_carplay111.so

Canonical GEN2 backup authority:
  /mnt/app/root/mibr-gen2-backup/libmibr_carplay111.pre-gen2.so
  /mnt/app/root/mibr-gen2-backup/libmibr_carplay111.pre-gen2.so.sha256
  /mnt/app/root/mibr-gen2-backup/installed-gen2.sha256

A legacy /mnt/app/eso/lib/libmibr_carplay111.so.pre-gen2 backup is only used as a one-time migration source when its sidecar hash proves the bytes.

smartphone_integrator.json is verified but not changed by these GEN2 scripts.


GEN2 D2 keyframe policy (next A/B run)
---------------------------------------
The D2 policy is runtime opt-in and volatile:

  ./gen2_keyframes.sh status
  ./gen2_keyframes.sh on
  ./gen2_keyframes.sh off

No reboot is required to toggle the policy after the new GEN2 library is loaded.

When enabled:
  - turns 0<->1 schedules a forceKeyFrame;
  - suggestUI schedules a forceKeyFrame;
  - event bursts are debounced for 250 ms;
  - requests are separated by at least 1 s;
  - if no new source IDR has appeared for 1 s, a watchdog recovery is armed;
  - the existing Stream 111 / codec / consumer generations stay alive;
  - Candidate-D waits for a newer source IDR and retries 1/2/4 s if necessary.

The policy is OFF after reboot unless explicitly enabled again. This is deliberate
for the vehicle A/B test.

Recommended A/B:
  1. start monitor + optional pre-TS capture with D2 OFF;
  2. reproduce one stale/artifact state;
  3. mark/snapshot;
  4. enable D2 with ./gen2_keyframes.sh on;
  5. repeat the same route/provider transitions;
  6. compare VC behavior plus source_idrs / D2 / resync counters.

The live monitor compact status now includes:
  d2=<enabled>/<pending-source-mask>
