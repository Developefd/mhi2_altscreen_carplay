#!/bin/ksh
set -u

BASE=/net/mmx/fs/sda0/esd/carplay-test
BIN=$BASE/libaltscreen111-gen2.so
HOOK=/mnt/app/eso/lib/libmibr_carplay111.so
CFG=/mnt/system/etc/eso/production/smartphone_integrator.json
BACKDIR=/mnt/app/root/mibr-gen2-backup
INSTALLED_SHA=$BACKDIR/installed-gen2.sha256
STATUS=/tmp/mibr-alt111-gen2.status
LOG=/tmp/altscreen111.log

find_sha(){
  for p in /mnt/app/root/altscreen-u2/bin/sha256sum /net/mmx/fs/sda0/esd/bin/sha256sum /usr/bin/sha256sum /bin/sha256sum; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  command -v sha256sum 2>/dev/null && return 0
  return 1
}
SHA=$(find_sha) || { echo "GEN2_VERIFY=FAIL_NO_SHA256"; exit 2; }
hash_file(){ "$SHA" "$1" 2>/dev/null | awk '{print $1; exit}'; }

echo "=== GEN2 VERIFY ==="

[ -r "$BIN" ] || { echo "GEN2_VERIFY=FAIL_STAGE_BINARY_MISSING"; exit 10; }
[ -r "$HOOK" ] || { echo "GEN2_VERIFY=FAIL_INSTALLED_HOOK_MISSING"; exit 11; }

EXPECTED=$(hash_file "$BIN")
ACTUAL=$(hash_file "$HOOK")
echo "staged_sha256=$EXPECTED"
echo "installed_sha256=$ACTUAL"
[ "$EXPECTED" = "$ACTUAL" ] || { echo "GEN2_VERIFY=FAIL_INSTALLED_HASH"; exit 12; }

RECORDED=$(awk '{print $1; exit}' "$INSTALLED_SHA" 2>/dev/null)
[ -n "$RECORDED" ] && [ "$RECORDED" = "$ACTUAL" ] || {
  echo "GEN2_VERIFY=FAIL_INSTALLED_MARKER recorded=$RECORDED actual=$ACTUAL"
  exit 12
}

grep -q "LD_PRELOAD=$HOOK" "$CFG" 2>/dev/null || { echo "GEN2_VERIFY=FAIL_PRELOAD_CONFIG"; exit 13; }

SID=$(pidin ar 2>/dev/null | awk '/[s]martphone_integrator/ {print $1; exit}')
DIO=$(pidin ar 2>/dev/null | awk '/[d]io_manager/ {print $1; exit}')
echo "smartphone_integrator_pid=${SID:-NONE}"
echo "dio_manager_pid=${DIO:-NONE}"

[ -n "${SID:-}" ] || { echo "GEN2_VERIFY=FAIL_NO_SMARTPHONE_INTEGRATOR"; exit 14; }

if [ -z "${DIO:-}" ]; then
  echo "GEN2_VERIFY=WAITING_FOR_DIO_MANAGER"
  echo "Connect wired CarPlay and rerun ./gen2_verify.sh"
  exit 0
fi

ENVTMP=/tmp/gen2-dio-env.$$
pidin -p "$DIO" environment > "$ENVTMP" 2>/dev/null || true
grep -E 'LD_PRELOAD|ALTSCREEN111_|IPL_CONFIG_DIR_DIO_MANAGER' "$ENVTMP" || true
grep -q "LD_PRELOAD=$HOOK" "$ENVTMP" || {
  rm -f "$ENVTMP"
  echo "GEN2_VERIFY=FAIL_DIO_PRELOAD_ENV"
  exit 15
}
rm -f "$ENVTMP"

[ -r "$STATUS" ] || {
  echo "GEN2_VERIFY=FAIL_NO_GEN2_STATUS"
  [ -r "$LOG" ] && tail -120 "$LOG" || true
  exit 16
}

echo
cat "$STATUS"
echo
echo "--- recent hook log ---"
tail -120 "$LOG" 2>/dev/null || true
echo
echo "GEN2_VERIFY=PASS"
