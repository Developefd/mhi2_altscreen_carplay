#!/bin/ksh
set -u

HOOK=/mnt/app/eso/lib/libmibr_carplay111.so
BACKDIR=/mnt/app/root/mibr-gen2-backup
BACKUP=$BACKDIR/libmibr_carplay111.pre-gen2.so
BACKUP_SHA=$BACKDIR/libmibr_carplay111.pre-gen2.so.sha256
INSTALLED_SHA=$BACKDIR/installed-gen2.sha256
TMP=$HOOK.gen2-restore.$$

find_sha(){
  for p in /mnt/app/root/altscreen-u2/bin/sha256sum /net/mmx/fs/sda0/esd/bin/sha256sum /usr/bin/sha256sum /bin/sha256sum; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  command -v sha256sum 2>/dev/null && return 0
  return 1
}
SHA=$(find_sha) || { echo "GEN2_RESTORE=FAIL_NO_SHA256"; exit 2; }
hash_file(){ "$SHA" "$1" 2>/dev/null | awk '{print $1; exit}'; }
cleanup(){ rm -f "$TMP" 2>/dev/null || true; }
trap cleanup 0 1 2 15

echo "=== GEN2 RESTORE ==="

[ -r "$BACKUP" ] || { echo "GEN2_RESTORE=FAIL_NO_BACKUP"; exit 10; }
EXPECTED=$(awk '{print $1; exit}' "$BACKUP_SHA" 2>/dev/null)
ACTUAL=$(hash_file "$BACKUP")
[ -n "$EXPECTED" ] && [ "$EXPECTED" = "$ACTUAL" ] || {
  echo "GEN2_RESTORE=FAIL_BACKUP_HASH expected=$EXPECTED actual=$ACTUAL"
  exit 11
}

CURRENT=MISSING
[ -r "$HOOK" ] && CURRENT=$(hash_file "$HOOK")
KNOWN_GEN2=$(awk '{print $1; exit}' "$INSTALLED_SHA" 2>/dev/null)
if [ "$CURRENT" != "MISSING" ] && [ "$CURRENT" != "$ACTUAL" ]; then
  [ -n "$KNOWN_GEN2" ] && [ "$CURRENT" = "$KNOWN_GEN2" ] || {
    echo "GEN2_RESTORE=FAIL_UNKNOWN_CURRENT_HOOK current=$CURRENT backup=$ACTUAL known_gen2=$KNOWN_GEN2"
    exit 12
  }
fi

mount -uw /mnt/app 2>/dev/null || { echo "GEN2_RESTORE=FAIL_MOUNT_APP_RW"; exit 12; }

cp "$BACKUP" "$TMP" &&
chmod 755 "$TMP" &&
mv "$TMP" "$HOOK"
RC=$?
sync
sync
mount -ur /mnt/app 2>/dev/null || true
[ $RC -eq 0 ] || { echo "GEN2_RESTORE=FAIL_COPY"; exit 13; }

FINAL=$(hash_file "$HOOK")
[ "$FINAL" = "$ACTUAL" ] || {
  echo "GEN2_RESTORE=FAIL_VERIFY expected=$ACTUAL actual=$FINAL"
  exit 14
}

if mount -uw /mnt/app 2>/dev/null; then
  rm -f "$INSTALLED_SHA" 2>/dev/null || true
  sync
  mount -ur /mnt/app 2>/dev/null || true
else
  echo "GEN2_RESTORE=FAIL_CLEAR_MARKER_MOUNT_RW"
  exit 15
fi

echo "GEN2_RESTORE=PASS"
echo "restored_sha256=$FINAL"
echo "REBOOT_REQUIRED=YES"
echo "NEXT=./gen2_reboot_fast.sh"
